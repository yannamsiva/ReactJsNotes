import React, { useState } from "react";

const Product = () => {
    const data = [
        {
            id: 1,
            name: 'Rice',
            qty: 25,
            price: 1300
        },
        {
            id: 2,
            name: 'SOAP',
            qty: 75,
            price: 130
        }
    ]
    const [id, setId] = useState();
    const [name, setName] = useState();
    const [qty, setQty] = useState();
    const [price, setPrice] = useState();
    const [products, setProducts] = useState(data);
    const create = (e) => {
        e.preventDefault();
        alert(id + " " + name + " " + qty + " " + price);
        let product = {
            id: id,
            name: name,
            qty: qty,
            price: price
        };
        let newList = products.concat(product);
        setProducts(newList);
        console.log(products);
    }
    const deleteProduct = (e, id) => {
        e.preventDefault();
        console.log(id);
        let updatedList = products.filter(product => product.id !== id);
        setProducts(updatedList);
    }
    const updateProduct = (e, id) => {
        e.preventDefault();
        alert("I want to update product Id: " + id);
        let product = products.filter(product => product.id == id);
        alert(product.id + " " + product.name + " " + product.qty + " " + product.price);
    }
    return (
        <div className="container">
            <div className="card">
                <div className="card-header">
                    <h1>Create Product</h1>
                </div>
                <div className="card-body">
                    <form>
                        <div className="mb-3">
                            <label for="exampleId" className="form-label">Product Id</label>
                            <input type="text" className="form-control" id="exampleid" name="id" onChange={(e) => {
                                setId(e.target.value)
                            }} />
                        </div>
                        <div className="mb-3">
                            <label for="exampleName" className="form-label">Product Name</label>
                            <input type="text" className="form-control" id="exampleName" name="name" onChange={(e) => {
                                setName(e.target.value)
                            }} />
                        </div>
                        <div className="mb-3">
                            <label for="exampleQty" className="form-label">Product Qty</label>
                            <input type="text" className="form-control" id="exampleqty" name="qty" onChange={(e) => {
                                setQty(e.target.value)
                            }} />
                        </div>
                        <div className="mb-3">
                            <label for="examplePrice" className="form-label">Product Price</label>
                            <input type="text" className="form-control" id="examplePrice" name="price" onChange={(e) => {
                                setPrice(e.target.value)
                            }} />
                        </div>
                        <button className="btn btn-primary" onClick={(e) => create(e, id)}>Create</button>
                    </form>
                </div>
                <hr />
                <div className="card">
                    <div className="card-header">
                        <h1>Product List</h1>
                    </div>
                    <div className="card-body">
                        <table className="table table-striped">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>Qty</th>
                                    <th>Price</th>
                                    <th colSpan={2}>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    products.map((element, index) => {
                                        return (
                                            <tr key={index}>

                                                <td>{element.id}</td>
                                                <td>{element.name}</td>
                                                <td>{element.qty}</td>
                                                <td>{element.price}</td>
                                                <td>
                                                    <button className="btn btn-primary" style={{ marginRight: 15 }} onClick={(e) => updateProduct(e, element.id)}>Edit</button>
                                                    <button className="btn btn-danger" onClick={(e) => deleteProduct(e, element.id)}>Delete</button>
                                                </td>
                                            </tr>
                                        )
                                    })
                                }
                            </tbody>
                        </table>
                    </div>
                </div>
                <div className="card">
                    <div className="card-header">
                        <h1>Update Product</h1>
                    </div>
                    <div className="card-body">
                        <form>
                            <div className="mb-3">
                                <label for="exampleId" className="form-label">Product Id</label>
                                <input type="text" className="form-control" id="exampleid" name="id"value={product.id} onChange={(e) => {
                                    setId(e.target.value)
                                }} />
                            </div>
                            <div className="mb-3">
                                <label for="exampleName" className="form-label">Product Name</label>
                                <input type="text" className="form-control" id="exampleName" name="name" value={product.name} onChange={(e) => {
                                    setName(e.target.value)
                                }} />
                            </div>
                            <div className="mb-3">
                                <label for="exampleQty" className="form-label">Product Qty</label>
                                <input type="text" className="form-control" id="exampleqty" name="qty" value={product.qty} onChange={(e) => {
                                    setQty(e.target.value)
                                }} />
                            </div>
                            <div className="mb-3">
                                <label for="examplePrice" className="form-label">Product Price</label>
                                <input type="text" className="form-control" id="examplePrice" name="price" value={product.price} onChange={(e) => {
                                    setPrice(e.target.value)
                                }} />
                            </div>
                            <button className="btn btn-primary" onClick={(e) => updateProduct(e, id)}>Update</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    )
}
export default Product;